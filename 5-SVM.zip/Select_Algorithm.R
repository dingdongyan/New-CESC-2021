rm(list=ls())
setwd('F:/小论文-515/5-SVM/')

#误判率 朴素贝叶斯：0.02173913、SVM：0.02173913
library(e1071)#SVM、朴素贝叶斯
library(randomForest)#随机森林
library(lattice)
library(survival)
library(Formula)
library(ggplot2)
library(Hmisc)
library(ggpubr)
library(survminer)
library(survcomp)
library(pROC)

clinic2020_CESC<-read.csv("Select_Algorithm_TOP10-KMeans_4.csv", header=T,row.names= 1, na.strings=c("NA"))#读入数据
clinic2020_CESC<-as.data.frame(clinic2020_CESC)
#fix(clinic2020_CESC)
patient.vital_status<-rep(1,length(clinic2020_CESC[,1]))#先令所有生存状态都为1
patient.vital_status[which(is.na(clinic2020_CESC$patient.days_to_death))]=0#将失访的生存状态标记为0

clinic2020_CESC$patient.vital_status<-patient.vital_status#给列表新增生存状态列
clinic2020_CESC$patient.days_to_last_followup[is.na(clinic2020_CESC$patient.days_to_last_followup)]<-0#最后访问天数为NA的将其最后访问天数改为0
clinic2020_CESC$patient.days_to_death[is.na(clinic2020_CESC$patient.days_to_death)]<-0#死亡天数为NA的将其死亡天数改为0
clinic2020_CESC$time<-clinic2020_CESC$patient.days_to_last_followup+clinic2020_CESC$patient.days_to_death#新增列表time列,其值为死亡天数和随访天数的和
#删除掉原来列表中的 patient.days_to_last_followup2020 和 patient.days_to_death 列
clinic2020_CESC<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.days_to_last_followup"),-which(names(clinic2020_CESC)=="patient.days_to_death"))]
#######################数据准备完毕
#######################k-means
clinic2020_CESC_kmeans<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.vital_status"),-which(names(clinic2020_CESC)=="time"))]

###K=2
set.seed(1)
clinic2020_CESC_kmeans_2<-kmeans(clinic2020_CESC_kmeans,center=2)
kmeansgroup2<-clinic2020_CESC_kmeans_2$cluster #分类贴标签
clinic2020_CESC_2<-clinic2020_CESC
#fix(clinic2020_CESC_2)
clinic2020_CESC_2$kmeansgroup2<-kmeansgroup2
fit2020_CESC_2 <- survfit(Surv(time, patient.vital_status) ~ kmeansgroup2, data = clinic2020_CESC_2)
#jpeg(file = "CESC_2means.jpg")
ggsurvplot(fit2020_CESC_2, pval=TRUE, data =clinic2020_CESC_2)
dev.off()

######SVM 2
set.seed(1)
#############SVM 
index_2020_CESC<-c(1:nrow(clinic2020_CESC))

testindex_2020_CESC<-sample(index_2020_CESC, trunc(length(index_2020_CESC)*0.3))##测试集
###2组
traindata_svm_2020_CESC_2<-clinic2020_CESC_2[-testindex_2020_CESC,]##重要特征及分组
#fix(traindata_svm_2020_CESC_2)
#colname_newdata<-colnames(traindata_svm_2020_CESC_2)
#write.table(traindata_svm_2020_CESC_2, "C:/Users/CQU_ddy/Desktop/COXPHTOP20-K=2-TrianSet-data.txt", col.names = colname_newdata, row.names = rownames(traindata_svm_2020_CESC_2), quote=F, sep = "\t")

testdata_svm_2020_CESC_2<-clinic2020_CESC_2[testindex_2020_CESC,]
#fix(testdata_svm_2020_CESC_2)
#colname_newdata<-colnames(testdata_svm_2020_CESC_2)
#write.table(testdata_svm_2020_CESC_2, "C:/Users/CQU_ddy/Desktop/COXPHTOP20-K=2-TestSet-data.txt", col.names = colname_newdata, row.names = rownames(testdata_svm_2020_CESC_2), quote=F, sep = "\t")

###ddy
traindata_svm_2020_CESC_2_0<-traindata_svm_2020_CESC_2[,c(-which(names(clinic2020_CESC)=="patient.vital_status"),-which(names(clinic2020_CESC)=="time"))]
#fix(traindata_svm_2020_CESC_2_0)
testdata_svm_2020_CESC_2_0<-testdata_svm_2020_CESC_2[,c(-which(names(clinic2020_CESC)=="patient.vital_status"),-which(names(clinic2020_CESC)=="time"))]
#fix(testdata_svm_2020_CESC_2_0)
dim(testdata_svm_2020_CESC_2_0)
###朴素贝叶斯
naiveBayes.model<-naiveBayes(kmeansgroup2~., data=traindata_svm_2020_CESC_2_0)
NB_predict<- predict(naiveBayes.model, newdata = testdata_svm_2020_CESC_2_0[,
                                                                            -which(names(testdata_svm_2020_CESC_2_0)=="kmeansgroup2")])
##混淆矩阵
table_NB <- table(testdata_svm_2020_CESC_2_0$kmeansgroup2, NB_predict, dnn=c("真实值","预测值"))
1 - sum(diag(table_NB))/sum(table_NB) # 计算误差

###随机森林
err<-as.numeric()
for(i in 1:(length(names(traindata_svm_2020_CESC_2_0)))-1){
  mtry_test <- randomForest(kmeansgroup2~., data=traindata_svm_2020_CESC_2_0, mtry=5)
  err<- append( err, mean( mtry_test$err.rate ) )
}
mtry<-which.min(err)
rf<-randomForest(kmeansgroup2~., data=traindata_svm_2020_CESC_2_0, mtry=mtry, ntree=900, importance=T)
pred1<-predict(rf,newdata=testdata_svm_2020_CESC_2_0[,-which(names(testdata_svm_2020_CESC_2_0)=="kmeansgroup2")])
##混淆矩阵
Freq1<-table(testdata_svm_2020_CESC_2_0[,which(names(testdata_svm_2020_CESC_2_0)=="kmeansgroup2")], pred1, dnn=c("真实值","预测值"))
1 - sum(diag(Freq1))/sum(Freq1) # 计算误差

###支持向量机SVM
clinic2020_datasvm_CESC_model_2<-svm(kmeansgroup2~., data=traindata_svm_2020_CESC_2_0, type = 'C',kernel = 'radial' )
clinic2020_datasvm_CESC_pre_2<-predict(clinic2020_datasvm_CESC_model_2,testdata_svm_2020_CESC_2_0[,-which(names(testdata_svm_2020_CESC_2_0)=="kmeansgroup2")])
##混淆矩阵
confusionmatrix_svm_2020_CESC_2<-table(testdata_svm_2020_CESC_2[,which(names(testdata_svm_2020_CESC_2)=="kmeansgroup2")],clinic2020_datasvm_CESC_pre_2,dnn=c("真实值","预测值"))
# 计算误差
1-sum(diag(confusionmatrix_svm_2020_CESC_2))/sum(
  confusionmatrix_svm_2020_CESC_2)
