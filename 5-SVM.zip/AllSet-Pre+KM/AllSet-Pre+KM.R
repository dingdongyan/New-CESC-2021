rm(list=ls())
setwd('F:/小论文-515/5-SVM/AllSet-Pre+KM/')

library(stats)
library(survival)
library(ggplot2)
library(ggpubr)
library(survminer)

clinic2020_CESC<-read.csv("AllSet-Pre-data.csv", header=T,row.names= 1, na.strings=c("NA"))
#alive为0，dead为1
dim(clinic2020_CESC)
fit2020_CESC <- survfit(Surv(Time, Status) ~ Pre_group, data = clinic2020_CESC)
ggsurvplot(fit2020_CESC, data =clinic2020_CESC, pval=TRUE, 
           palette=c('#B10026', '#06592A', '#F28522', '#AF58BA'),
           break.x.by=1000, break.y.by=0.2,#设定x、y轴刻度的间距
           font.main = 16,
           font.x = 14,
           font.y = 14,
           font.tickslab = 14,
           font.tickslab.size =4,
           size=1.5,
           censor.size=7,
           axis.line=30,
           )

km<-survdiff(formula = Surv(Time, Status) ~ Pre_group, data = clinic2020_CESC)
km

dev.off()

