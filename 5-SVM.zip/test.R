rm(list=ls())
setwd('F:/小论文-515/5-SVM')

library(e1071)
library(lattice)
library(survival)
library(Formula)
library(ggplot2)
library(Hmisc)
library(ggpubr)
library(survminer)
library(survcomp)
library(pROC)
library(sampling)

clinic2020_CESC<-read.csv("SVM+TOP10-KMeans_4.csv", header=T,row.names= 1, na.strings=c("NA"))#读入数据
fix(clinic2020_CESC)
dim(clinic2020_CESC)
clinic2020_CESC<-as.data.frame(clinic2020_CESC)
patient.vital_status<-rep(1,length(clinic2020_CESC[,1]))#先令所有生存状态都为1
patient.vital_status[which(is.na(clinic2020_CESC$patient.days_to_death))]=0#将失访的生存状态标记为0

clinic2020_CESC$patient.vital_status<-patient.vital_status#给列表新增生存状态列
clinic2020_CESC$patient.days_to_last_followup[is.na(clinic2020_CESC$patient.days_to_last_followup)]<-0#最后访问天数为NA的将其最后访问天数改为0
clinic2020_CESC$patient.days_to_death[is.na(clinic2020_CESC$patient.days_to_death)]<-0#死亡天数为NA的将其死亡天数改为0
clinic2020_CESC$time<-clinic2020_CESC$patient.days_to_last_followup+clinic2020_CESC$patient.days_to_death#新增列表time列,其值为死亡天数和随访天数的和
#删除掉原来列表中的 patient.days_to_last_followup2020 和 patient.days_to_death 列
clinic2020_CESC<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.days_to_last_followup"),-which(names(clinic2020_CESC)=="patient.days_to_death"))]
#######################数据准备完毕
#######################k-means
clinic2020_CESC_kmeans<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.vital_status"),-which(names(clinic2020_CESC)=="time"))]

##K=4
set.seed(1)
clinic2020_CESC_kmeans_4<-kmeans(clinic2020_CESC_kmeans, center=4, iter.max=20, algorithm= "Hartigan-Wong",trace=FALSE)
kmeansgroup4<-clinic2020_CESC_kmeans_4$cluster
clinic2020_CESC_4<-clinic2020_CESC
clinic2020_CESC_4$kmeansgroup4<-kmeansgroup4
fit2020_CESC_4 <- survfit(Surv(time, patient.vital_status) ~ kmeansgroup4, data = clinic2020_CESC_4)
ggsurvplot(fit2020_CESC_4 , data =clinic2020_CESC_4, pval=TRUE, palette=c('red', 'blue', 'green', 'purple'))
dev.off()

clinic2020_CESC_4<-clinic2020_CESC_4[order(clinic2020_CESC_4[,'kmeansgroup4']),]#升序排列
fix(clinic2020_CESC_4)
n_1<-round(sum(clinic2020_CESC_4$kmeansgroup4=='1')*0.7)
n_1
n_2<-round(sum(clinic2020_CESC_4$kmeansgroup4=='2')*0.7)
n_2
n_3<-round(sum(clinic2020_CESC_4$kmeansgroup4=='3')*0.7)
n_3
n_4<-round(sum(clinic2020_CESC_4$kmeansgroup4=='4')*0.7)
n_4
sub_train=strata(clinic2020_CESC_4,stratanames=c("kmeansgroup4"),
                 size=c(n_1,n_2,n_3,n_4),
                 method="srswor")
fix(sub_train)
sum(sub_train$kmeansgroup4=='1')==n_1
sum(sub_train$kmeansgroup4=='2')==n_2
sum(sub_train$kmeansgroup4=='3')==n_3
sum(sub_train$kmeansgroup4=='4')==n_4

