rm(list=ls())
setwd('F:/小论文-515/5-SVM')

library(e1071)
library(lattice)
library(survival)
library(Formula)
library(ggplot2)
library(Hmisc)
library(ggpubr)
library(survminer)
library(survcomp)
library(pROC)
library(sampling)

clinic2021_CESC<-read.csv("SVM+TOP10-KMeans_4.csv", header=T,row.names= 1, na.strings=c("NA"))#读入数据
clinic2021_CESC<-as.data.frame(clinic2021_CESC)
patient.vital_status<-rep(1,length(clinic2021_CESC[,1]))#先令所有生存状态都为1
patient.vital_status[which(is.na(clinic2021_CESC$patient.days_to_death))]=0#将失访的生存状态标记为0

clinic2021_CESC$patient.vital_status<-patient.vital_status#给列表新增生存状态列
clinic2021_CESC$patient.days_to_last_followup[is.na(clinic2021_CESC$patient.days_to_last_followup)]<-0#最后访问天数为NA的将其最后访问天数改为0
clinic2021_CESC$patient.days_to_death[is.na(clinic2021_CESC$patient.days_to_death)]<-0#死亡天数为NA的将其死亡天数改为0
clinic2021_CESC$time<-clinic2021_CESC$patient.days_to_last_followup+clinic2021_CESC$patient.days_to_death#新增列表time列,其值为死亡天数和随访天数的和
#删除掉原来列表中的 patient.days_to_last_followup2021 和 patient.days_to_death 列
clinic2021_CESC<-clinic2021_CESC[,c(-which(names(clinic2021_CESC)=="patient.days_to_last_followup"),-which(names(clinic2021_CESC)=="patient.days_to_death"))]
#######################数据准备完毕
#######################k-means
clinic2021_CESC_kmeans<-clinic2021_CESC[,c(-which(names(clinic2021_CESC)=="patient.vital_status"),-which(names(clinic2021_CESC)=="time"))]

##K=4
set.seed(1)
clinic2021_CESC_kmeans_4<-kmeans(clinic2021_CESC_kmeans, center=4, iter.max=20, algorithm= "Hartigan-Wong",trace=FALSE)
kmeansgroup4<-clinic2021_CESC_kmeans_4$cluster
clinic2021_CESC_4<-clinic2021_CESC
clinic2021_CESC_4$kmeansgroup4<-kmeansgroup4
fit2021_CESC_4 <- survfit(Surv(time, patient.vital_status) ~ kmeansgroup4, data = clinic2021_CESC_4)
#ggsurvplot(fit2021_CESC_4 , data =clinic2021_CESC_4, pval=TRUE, palette=c('red', 'blue', 'green', 'purple'))
#dev.off()

#按kmeans分组排序，1,2,3,4
clinic2021_CESC_4<-clinic2021_CESC_4[order(clinic2021_CESC_4[,'kmeansgroup4']),]
n_1<-round(sum(clinic2021_CESC_4$kmeansgroup4=='1')*0.7)
n_2<-round(sum(clinic2021_CESC_4$kmeansgroup4=='2')*0.7)
n_3<-round(sum(clinic2021_CESC_4$kmeansgroup4=='3')*0.7)
n_4<-round(sum(clinic2021_CESC_4$kmeansgroup4=='4')*0.7)
#不放回，随机分层抽样，每个分组抽取70%样本作为训练集
sub_train=strata(clinic2021_CESC_4,stratanames=c("kmeansgroup4"),
                 size=c(n_1,n_2,n_3,n_4),
                 method="srswor")
#训练集数据
traindata_svm_2021_CESC_4<-clinic2021_CESC_4[sub_train$ID_unit,]
#fix(traindata_svm_2021_CESC_4)
dim(traindata_svm_2021_CESC_4)#215  13 训练集共计215个样本
#write.table(traindata_svm_2021_CESC_4, "F:/小论文-515/5-SVM/COXPHTOP10-K=4-TrainSet.txt", quote=F, sep = "\t")

#测试集数据
testdata_svm_2021_CESC_4<-clinic2021_CESC_4[-sub_train$ID_unit,]
#fix(testdata_svm_2021_CESC_4)
dim(testdata_svm_2021_CESC_4)#215  13 训练集共计215个样本
#write.table(testdata_svm_2021_CESC_4, "F:/小论文-515/5-SVM/COXPHTOP10-K=4-TestSet.txt", quote=F, sep = "\t")

###ddy
traindata_svm_2021_CESC_4_0<-traindata_svm_2021_CESC_4[,c(-which(names(clinic2021_CESC)=="patient.vital_status"),-which(names(clinic2021_CESC)=="time"))]
#fix(traindata_svm_2021_CESC_4_0)
testdata_svm_2021_CESC_4_0<-testdata_svm_2021_CESC_4[,c(-which(names(clinic2021_CESC)=="patient.vital_status"),-which(names(clinic2021_CESC)=="time"))]
#fix(testdata_svm_2021_CESC_4_0)

clinic2021_datasvm_CESC_model_4<-svm(kmeansgroup4~., data=traindata_svm_2021_CESC_4_0, type='C', kernel='radial', cost=5, gamma=0.05, cross=10, scale=FALSE)
clinic2021_datasvm_CESC_pre_4<-predict(clinic2021_datasvm_CESC_model_4,testdata_svm_2021_CESC_4_0[,-which(names(testdata_svm_2021_CESC_4_0)=="kmeansgroup4")])
#write.table(clinic2021_datasvm_CESC_pre_4, "F:/小论文-515/5-SVM/K=4-TestSet/COXPHTOP10-K=4-TestSet-pre.txt", quote=F, sep = "\t")
confusionmatrix_svm_2021_CESC_4<-table(testdata_svm_2021_CESC_4[,which(names(testdata_svm_2021_CESC_4)=="kmeansgroup4")],clinic2021_datasvm_CESC_pre_4,dnn=c("真实值","预测值"))

confusionmatrix_svm_2021_CESC_4##混淆矩阵
### 误判率 0.06521739
1-sum(diag(confusionmatrix_svm_2021_CESC_4))/sum(confusionmatrix_svm_2021_CESC_4)

######################### K=4 Test ROC
setwd('F:/小论文-515/5-SVM/K=4-TestSet/')
Test_ROC_data_1<-read.csv("K=4-Group1-test-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Test1 <- roc(Test_ROC_data_1$kmeansgroup4,Test_ROC_data_1$Pre_group)

plot(modelroc_4_Test1,
     col="red", ##曲线颜色
     print.auc=TRUE, ##图像上输出AUC的值
     print.auc.x=0.4, print.auc.y=0.5, ##图像上输出AUC值,坐标为(x, y)
     auc.polygon=TRUE, ##设置AUC曲线下填充
     auc.polygon.col="white", ##设置AUC曲线下填充颜色
     max.auc.polygon=TRUE, ##填充整个图像 
     smooth=F, ##绘制不平滑曲线
     legacy.axes=TRUE)  ##使横轴从0到1，表示为1-特异度

Test_ROC_data_2<-read.csv("K=4-Group2-test-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Test2 <- roc(Test_ROC_data_2$kmeansgroup4,Test_ROC_data_2$Pre_group)
plot.roc(modelroc_4_Test2,
         add=T, ##增加曲线
         col="black", ##曲线颜色为红色
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.4, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

Test_ROC_data_3<-read.csv("K=4-Group3-test-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Test3 <- roc(Test_ROC_data_3$kmeansgroup4,Test_ROC_data_3$Pre_group)
plot.roc(modelroc_4_Test3,
         add=T, ##增加曲线
         col="green", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.3, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

Test_ROC_data_4<-read.csv("K=4-Group4-test-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Test4 <- roc(Test_ROC_data_4$kmeansgroup4,Test_ROC_data_4$Pre_group)
plot.roc(modelroc_4_Test4,
         add=T, ##增加曲线
         col="#AF58BA", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.2, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

legend(0.99,0.65, ##图例位置
       bty="n", ##图例样式,默认为“o”
       title="", ## 引号内添加图例标题
       legend=c("Group 1", "Group 2", "Group 3", "Group 4"), ##添加分组
       col=c("red", "black", "green", "#AF58BA"), ##颜色跟前面一致
       lwd=2) ##线条粗细

dev.off()

#################################### K=4 training set
clinic2021_datasvm_CESC_pre_4_train<-predict(clinic2021_datasvm_CESC_model_4,traindata_svm_2021_CESC_4_0[,-which(names(traindata_svm_2021_CESC_4_0)=="kmeansgroup4")])
#write.table(clinic2021_datasvm_CESC_pre_4_train, "F:/小论文-515/5-SVM/K=4-TrainingSet/COXPHTOP10-K=4-TrainSet-pre.txt", quote=F, sep = "\t")
confusionmatrix_svm_2021_CESC_4_train<-table(traindata_svm_2021_CESC_4[,which(names(traindata_svm_2021_CESC_4)=="kmeansgroup4")],clinic2021_datasvm_CESC_pre_4_train,dnn=c("真实值","预测值"))

confusionmatrix_svm_2021_CESC_4_train##混淆矩阵
### 误判率 0.009302326
1-sum(diag(confusionmatrix_svm_2021_CESC_4_train))/sum(confusionmatrix_svm_2021_CESC_4_train)

############################
############################### K=4 Train ROC
setwd('F:/小论文-515/5-SVM/K=4-TrainingSet/')
Train_ROC_data_1<-read.csv("K=4-Group1-training-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Train1 <- roc(Train_ROC_data_1$kmeansgroup4,Train_ROC_data_1$Pre_group)

plot(modelroc_4_Train1,
     col="red", ##曲线颜色
     print.auc=TRUE, ##图像上输出AUC的值
     print.auc.x=0.4, print.auc.y=0.5, ##图像上输出AUC值,坐标为(x, y)
     auc.polygon=TRUE, ##设置AUC曲线下填充
     auc.polygon.col="white", ##设置AUC曲线下填充颜色
     max.auc.polygon=TRUE, ##填充整个图像 
     #grid=c(0.1, 0.2), ##绘制列线条间距为0.1, 行线条间距为0.2
     #grid.col=c("green", "red"), ##绘制列线条颜色为绿色, 行线条颜色为红色
     #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
     smooth=F, ##绘制不平滑曲线
     legacy.axes=TRUE)  ##使横轴从0到1，表示为1-特异度

Train_ROC_data_2<-read.csv("K=4-Group2-training-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Train2 <- roc(Train_ROC_data_2$kmeansgroup4,Train_ROC_data_2$Pre_group)
plot.roc(modelroc_4_Train2,
         add=T, ##增加曲线
         col="black", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.4, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

Train_ROC_data_3<-read.csv("K=4-Group3-training-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Train3 <- roc(Train_ROC_data_3$kmeansgroup4,Train_ROC_data_3$Pre_group)
plot.roc(modelroc_4_Train3,
         add=T, ##增加曲线
         col="green", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.3, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

Train_ROC_data_4<-read.csv("K=4-Group4-training-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_Train4 <- roc(Train_ROC_data_4$kmeansgroup4,Train_ROC_data_4$Pre_group)
plot.roc(modelroc_4_Train4,
         add=T, ##增加曲线
         col="#AF58BA", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.2, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

legend(0.99,0.65, ##图例位置
       bty="n", ##图例样式,默认为“o”
       title="", ## 引号内添加图例标题
       legend=c("Group 1", "Group 2", "Group 3", "Group 4"), ##添加分组
       col=c("red", "black", "green", "#AF58BA"), ##颜色跟前面一致
       lwd=2) ##线条粗细

dev.off()

######################################### 307 ALL ###############################
################################### 307 All ####################################
colname_newdata<-colnames(clinic2021_CESC_4)
write.table(clinic2021_CESC_4, "F:/小论文-515/5-SVM/K=4-AllSet/COXPHTOP10-K=4-307AllSet-data.txt", col.names = colname_newdata, row.names = rownames(clinic2021_CESC_4), quote=F, sep = "\t")

clinic2021_CESC_4_new<-clinic2021_CESC_4
clinic2021_CESC_4_Allpre<-clinic2021_CESC_4_new[,c(-which(names(clinic2021_CESC_4_new)=="patient.vital_status"),-which(names(clinic2021_CESC_4_new)=="time"))]
clinic2021_datasvm_CESC_pre_4_Allpre<-predict(clinic2021_datasvm_CESC_model_4,clinic2021_CESC_4_Allpre[,-which(names(clinic2021_CESC_4_Allpre)=="kmeansgroup4")])
write.table(clinic2021_datasvm_CESC_pre_4_Allpre, "F:/小论文-515/5-SVM/K=4-AllSet/COXPHTOP10-K=4-307AllSet-pre.txt", quote=F, sep = "\t")
confusionmatrix_svm_2021_CESC_4_Allpre<-table(clinic2021_CESC_4_new[,which(names(clinic2021_CESC_4_new)=="kmeansgroup4")],clinic2021_datasvm_CESC_pre_4_Allpre,dnn=c("真实值","预测值"))

confusionmatrix_svm_2021_CESC_4_Allpre##混淆矩阵
### 误判率 0.02605863
1-sum(diag(confusionmatrix_svm_2021_CESC_4_Allpre))/sum(confusionmatrix_svm_2021_CESC_4_Allpre)

###########################################
############################### K=4 307AllPre ROC
setwd('F:/小论文-515/5-SVM/K=4-AllSet/')
AllSet_ROC_data_1<-read.csv("K=4-Group1-AllSet-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_AllSet1 <- roc(AllSet_ROC_data_1$kmeansgroup4,AllSet_ROC_data_1$Pre_group)

plot(modelroc_4_AllSet1,
     col="red", ##曲线颜色
     print.auc=TRUE, ##图像上输出AUC的值
     print.auc.x=0.4, print.auc.y=0.5, ##图像上输出AUC值,坐标为(x, y)
     auc.polygon=TRUE, ##设置AUC曲线下填充
     auc.polygon.col="white", ##设置AUC曲线下填充颜色
     max.auc.polygon=TRUE, ##填充整个图像 
     #grid=c(0.1, 0.2), ##绘制列线条间距为0.1, 行线条间距为0.2
     #grid.col=c("green", "red"), ##绘制列线条颜色为绿色, 行线条颜色为红色
     #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
     smooth=F, ##绘制不平滑曲线
     legacy.axes=TRUE)  ##使横轴从0到1，表示为1-特异度

AllSet_ROC_data_2<-read.csv("K=4-Group2-AllSet-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_AllSet2 <- roc(AllSet_ROC_data_2$kmeansgroup4,AllSet_ROC_data_2$Pre_group)
plot.roc(modelroc_4_AllSet2,
         add=T, ##增加曲线
         col="black", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.4, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

AllSet_ROC_data_3<-read.csv("K=4-Group3-AllSet-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_AllSet3 <- roc(AllSet_ROC_data_3$kmeansgroup4,AllSet_ROC_data_3$Pre_group)
plot.roc(modelroc_4_AllSet3,
         add=T, ##增加曲线
         col="green", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.3, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

AllSet_ROC_data_4<-read.csv("K=4-Group4-AllSet-ROC-data.csv", header=T,row.names= 1, na.strings=c("NA"))
modelroc_4_AllSet4 <- roc(AllSet_ROC_data_4$kmeansgroup4,AllSet_ROC_data_4$Pre_group)
plot.roc(modelroc_4_AllSet4,
         add=T, ##增加曲线
         col="#AF58BA", ##曲线颜色为红色
         #print.thres=TRUE, print.thres.cex=0.6, ##图像上输出最佳截断值,并使其字体缩放0.8倍
         print.auc=TRUE, ##图像上输出AUC的值
         print.auc.x=0.4, print.auc.y=0.2, ##图像上输出AUC值,坐标为(x, y)
         smooth=F)

legend(0.99,0.65, ##图例位置
       bty="n", ##图例样式,默认为“o”
       title="", ## 引号内添加图例标题
       legend=c("Group 1", "Group 2", "Group 3", "Group 4"), ##添加分组
       col=c("red", "black", "green", "#AF58BA"), ##颜色跟前面一致
       lwd=2) ##线条粗细

dev.off()
