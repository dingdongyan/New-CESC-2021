rm(list=ls())#alive为0，dead为1
setwd('F:/小论文-515/3-COXPH/42-KM/42/')

library(stats)
library(survival)
library(ggplot2)
library(ggpubr)
library(survminer)

clinic2020_CESC<-read.table('42+Survival-CESC_diff_miRNA.txt', head=TRUE, sep = '\t', row.names = 1, check.names = F, quote = "")
dim(clinic2020_CESC)
clinic2020_CESC<-as.data.frame(clinic2020_CESC)

row_name<-rownames(clinic2020_CESC)
col_name<-colnames(clinic2020_CESC)

###307All-data
setwd('F:/小论文-515/Figure/SF3-42/42+All/')
for(i in c(3:length(col_name))){
  b<-col_name[i]
  clinic2020_CESC<-clinic2020_CESC[order(clinic2020_CESC[,b]),]#升序排列
  #fix(clinic2020_CESC)
  Group<-rep('Low',length(clinic2020_CESC[,1]))#先令所有生存状态都为1
  clinic2020_CESC$miRNA<-Group
  clinic2020_CESC$miRNA[154:307]<-'High'
  #fix(clinic2020_CESC)
  fit2020_CESC <- survfit(Surv(Time, Status) ~ miRNA, data = clinic2020_CESC)
  gg<-ggsurvplot(fit2020_CESC , data =clinic2020_CESC, pval=TRUE, 
                 #palette=c('red', 'blue'),
                 palette=c('#B10026', '#06592A'),
                 break.x.by=1000, break.y.by=0.2,#设定x、y轴刻度的间距
                 font.main = 16,
                 font.x = 14,
                 font.y = 14,
                 font.tickslab = 14,
                 font.tickslab.size =4,
                 size=1.5,
                 censor.size=7,
                 axis.line=30,
                 )
  ggsave(paste('No.',as.character(i-2),'-',b,'-',"KM.jpg"), plot = print(gg))
  #ggsave(gg,filename = paste(b,"1KM.jpg"),width = 12,height = 9)
  #dev.off()
  clinic2020_CESC<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="miRNA"))]
}

###上下1/4-data
setwd('F:/小论文-515/Figure/SF3-42/42+0.25/')
for(i in c(3:length(col_name))){
  b<-col_name[i]
  clinic2020_CESC<-clinic2020_CESC[order(clinic2020_CESC[,b]),]#升序排列
  #fix(clinic2020_CESC)
  Group<-rep('Low',length(clinic2020_CESC[,1]))#先令所有生存状态都为1
  clinic2020_CESC$miRNA<-Group
  clinic2020_CESC$miRNA[154:307]<-'High'
  #fix(clinic2020_CESC)
  clinic2020_CESC2<-rbind(clinic2020_CESC[1:77,], clinic2020_CESC[231:307,])
  #fix(clinic2020_CESC2)
  fit2020_CESC <- survfit(Surv(Time, Status) ~ miRNA, data = clinic2020_CESC2)
  gg<-ggsurvplot(fit2020_CESC , data =clinic2020_CESC2, pval=TRUE, 
                 palette=c('#B10026', '#06592A'),
                 break.x.by=1000, break.y.by=0.2,#设定x、y轴刻度的间距
                 font.main = 16,
                 font.x = 14,
                 font.y = 14,
                 font.tickslab = 14,
                 font.tickslab.size =4,
                 size=1.5,
                 censor.size=7,
                 axis.line=30)
  ggsave(paste('0.25','-','No.',as.character(i-2),'-',b,'-',"KM.jpg"), plot = print(gg))
  clinic2020_CESC<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="miRNA"))]
}


