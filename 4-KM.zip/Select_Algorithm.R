rm(list=ls())
setwd('F:/小论文-515/4-KM/')

library(tibble)
library(stats)
library(survival)
library(ggplot2)
library(ggpubr)

clinic2020_CESC<-read.csv("42-COXPH-Diff-miRNA.csv", header=T,row.names= 1, na.strings=c("NA"))#读入数据

clinic2020_CESC<-t(clinic2020_CESC)
clinic2020_CESC<-as.data.frame(clinic2020_CESC)
patient.vital_status<-rep(1,length(clinic2020_CESC[,1]))#先令所有生存状态都为1
patient.vital_status[which(is.na(clinic2020_CESC$patient.days_to_death))]=0#将失访的生存状态标记为0

clinic2020_CESC$patient.vital_status<-patient.vital_status#给列表新增生存状态列,alive为0,dead为1
clinic2020_CESC$patient.days_to_last_followup[is.na(clinic2020_CESC$patient.days_to_last_followup)]<-0#最后访问天数为NA的将其最后访问天数改为0
clinic2020_CESC$patient.days_to_death[is.na(clinic2020_CESC$patient.days_to_death)]<-0#死亡天数为NA的将其死亡天数改为0
clinic2020_CESC$time<-clinic2020_CESC$patient.days_to_last_followup+clinic2020_CESC$patient.days_to_death#新增列表time列,其值为死亡天数和随访天数的和

#删除掉原来列表中的 patient.days_to_last_followup2020 和 patient.days_to_death 列
clinic2020_CESC<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.days_to_last_followup"),-which(names(clinic2020_CESC)=="patient.days_to_death"))]

#######################数据准备完毕
#######################k-means
clinic2020_CESC_kmeans<-clinic2020_CESC[,c(-which(names(clinic2020_CESC)=="patient.vital_status"),-which(names(clinic2020_CESC)=="time"))]

###K=3,筛选聚类最佳参数
set.seed(1)

#K=3，algorithm="Lloyd"时K-Means聚类
gvhd.lloyd <- kmeans(clinic2020_CESC_kmeans,centers=3, 
                     algorithm="Lloyd", iter.max=20)
#K=3，algorithm="Hartigan-Wong"时K-Means聚类
gvhd.hartiganwong <- kmeans(clinic2020_CESC_kmeans, centers=3, 
                            algorithm= "Hartigan-Wong", iter.max = 20)
#K=3，algorithm=" MacQueen "时K-Means聚类
gvhd.macqueen<-kmeans(clinic2020_CESC_kmeans,centers=3,
                      algorithm="MacQueen", iter.max = 20)
#计算每组聚类效果的簇内误差平方总和withinss和簇间误差平方和betweenss
tibble(algorithm = c("Lloyd", "Hartigan-Wong","MacQueen"),
       withinss=c(gvhd.lloyd$totss,gvhd.hartiganwong$totss, gvhd.macqueen$totss),
       betweenss=c(gvhd.lloyd$betweenss, gvhd.hartiganwong$betweenss, 
                   gvhd.macqueen$betweenss))

