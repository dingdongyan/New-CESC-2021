rm(list=ls())
setwd('F:/小论文-515/4-KM/K=4-data/')

library(stats)
library(survival)
library(ggplot2)
library(ggpubr)
library(survminer)

clinic2020_CESC<-read.csv("KM-TOP5-KMeans_4.csv", header=T,row.names= 1, na.strings=c("NA"))
#alive为0，dead为1
dim(clinic2020_CESC)
fit2020_CESC <- survfit(Surv(Time, Status) ~kmeansgroup4 , data = clinic2020_CESC)
ggsurvplot(fit2020_CESC , data =clinic2020_CESC, pval=TRUE, palette=c('#E9002D', '#FFAA00', '#00B000'))

dev.off()
km<-survdiff(formula = Surv(Time, Status) ~kmeansgroup4 , data = clinic2020_CESC)
