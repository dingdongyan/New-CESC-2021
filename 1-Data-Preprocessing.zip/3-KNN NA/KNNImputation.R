rm(list=ls())
setwd('F:/小论文-426/1-Data-Preprocessing/3-KNN NA/')

library(DMwR2)

#读入数据
data1<- read.table("307-377-0.2-NA-Primary-CESC.miRseq_RPKM.txt",head = T,row.names=1,sep="\t")

dim(data1)
#k=8 加权平均法替补缺失值
knnOutput<-knnImputation(data1, k = 8, scale = TRUE, meth = "weighAvg", distData = NULL)
#检测是否替补所有缺失值
sum(is.na(knnOutput)) #检查是否插补所有NA值
#fix(knnOutput)
write.table(knnOutput, "./KNN-307-377-0.2-miRseq_RPKM.txt", quote=F, sep = "\t")


