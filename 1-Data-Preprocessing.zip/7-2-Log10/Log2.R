rm(list=ls())
setwd('F:/小论文-515/1-Data-Preprocessing/7-Log2/')

#读入数据
data1<- read.table("New-KNN-307-377-0.2-miRseq_RPKM.txt",head = T,row.names=1,sep="\t")
dim(data1)

data2<-log2(data1)

write.table(data2, "./Log2-307-377-0.2-miRseq.txt", col.names = colnames(data1), row.names = rownames(data1),quote=F, sep = "\t")


