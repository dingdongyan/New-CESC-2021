rm(list=ls())
setwd('F:/小论文-515/1-Data-Preprocessing/9-heatmap/')

library(pheatmap)

#读入数据
data1<- read.table("Z-Score-377-307-0.2-miRseq.txt",head = T,row.names=1,sep="\t")
dim(data1)
data1<-as.matrix(data1)
#查看是否有缺失值
data1[is.na(data1)]

a<-pheatmap(data1 ,scale="row", clustering_method = "ward",
            clustering_distance_rows = "euclidean",
            cluster_row=TRUE,cluster_cols=TRUE,
            color = colorRampPalette(c("MediumBlue","white","red"))(256)
           #color = colorRampPalette(colors = c("blue","white","red"))(100)
           #color = colorRampPalette(c("navy", "white", "firebrick3"))(50))
           )

dev.off()         

order_row = a$tree_row$order  #记录热图的行排序
order_col = a$tree_col$order    #记录热图的列排序
datat = data.frame(data1[order_row,order_col])   # 按照热图的顺序，重新排原始数据
datat = data.frame(rownames(datat),datat,check.names =F)  # 将行名加到表格数据中
colnames(datat)[1] = "Sample" 
write.table(datat,file="heatmap-KNN-377-307-0.2.txt",row.names=FALSE,quote = FALSE,sep='\t')  #输出结果，按照热图中的顺序


