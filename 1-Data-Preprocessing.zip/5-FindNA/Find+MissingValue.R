rm(list=ls())
setwd('F:/小论文-427/1-Data-Preprocessing/5-FindNA/')

OutlineData<-read.table('Quantile-307-377-0.2-miRseq.txt', head=TRUE, sep = '\t', row.names = 1, check.names = F, quote = "")
RawData<-read.table('RawData-307-377-0.2-miRseq.txt', head=TRUE, sep = '\t', row.names = 1, check.names = F, quote = "")
dim(OutlineData)
dim(RawData)

col_name<-colnames(OutlineData)
row_name<-rownames(OutlineData)

#按列处理，先处理好一个miRNA再处理下一个
for(j in c(1:length(col_name))){
  #按行精准到每个样本的该miRNA表达值
  for(i in c(1:length(row_name))){
    if(is.na(RawData[i,j])){
      OutlineData[i,j]<-NA
    }
  }
}

write.table(OutlineData, "./NA-307-377-0.2-miRseq.txt", col.names = col_name, row.names = row_name,quote=F, sep = "\t")



