rm(list=ls())
setwd('F:/小论文-427/1-Data-Preprocessing/6-KNNImputation/')

library(DMwR2)

#读入数据
data1<- read.table("NA-307-377-0.2-miRseq.txt",head = T,row.names=1,sep="\t")

dim(data1)
nrow(data1)
sum(complete.cases(data1))
#k=8 加权平均法替补缺失值
knnOutput<-knnImputation(data1, k = 1, scale = TRUE, meth = "weighAvg", distData = NULL)#检测是否替补所有缺失值
sum(is.na(knnOutput)) #检查是否插补所有NA值
#fix(knnOutput)
write.table(knnOutput, "./New-KNN-307-377-0.2-miRseq_RPKM.txt", quote=F, sep = "\t")


