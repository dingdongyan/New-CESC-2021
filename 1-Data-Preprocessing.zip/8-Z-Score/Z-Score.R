rm(list=ls())
setwd('F:/小论文-515/1-Data-Preprocessing/8-Z-Score/')

#读入数据
data1<- read.table("Log2-307-377-0.2-miRseq.txt",head = T,row.names=1,sep="\t")
dim(data1)
data1<-data.frame(data1)
#fix(data1)
#find z-scores of each column,按列处理
data2<-sapply(data1, function(data1) (data1-mean(data1))/sd(data1))
dim(data2)

write.table(data2, "./Z-Score-307-377-0.2-miRseq.txt", col.names = colnames(data1), row.names = rownames(data1), quote=F, sep = "\t")
